import React, { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform, useMotionValueEvent, AnimatePresence } from 'motion/react';

const archiveItems = [
  { id: 1, year: "199X", title: "Study in Form", images: ["/input_file_10.jpg", "/input_file_11.jpg", "/input_file_12.jpg"], description: "Early explorations in structural minimalism." },
  { id: 2, year: "199X", title: "Analog Dreams", images: ["/input_file_13.jpg", "/input_file_14.jpg", "/input_file_10.jpg"], description: "A return to tactile fabrics and raw edges." },
  { id: 3, year: "199X", title: "Raw Essence", images: ["/input_file_11.jpg", "/input_file_13.jpg", "/input_file_14.jpg"], description: "Stripping away the unnecessary." },
  { id: 4, year: "199X", title: "The Omission", images: ["/input_file_12.jpg", "/input_file_10.jpg", "/input_file_11.jpg"], description: "What is left out is as important as what remains." },
  { id: 5, year: "199X", title: "Sculptural", images: ["/input_file_14.jpg", "/input_file_12.jpg", "/input_file_13.jpg"], description: "Garments treated as wearable architecture." },
  { id: 6, year: "199X", title: "Void Space", images: ["/input_file_10.jpg", "/input_file_14.jpg", "/input_file_11.jpg"], description: "Embracing negative space in design." },
];

const ArchiveItem: React.FC<{ item: any, index: number }> = ({ item, index }) => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  const imageY = useTransform(scrollYProgress, [0, 1], ["-10%", "10%"]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [loadedImages, setLoadedImages] = useState<boolean[]>(new Array(item.images.length).fill(false));

  const handleImageLoad = (index: number) => {
    setLoadedImages((prev) => {
      const next = [...prev];
      next[index] = true;
      return next;
    });
  };

  const handleDragEnd = (e: any, { offset }: any) => {
    const swipeDistance = offset.x;
    if (swipeDistance < -50) {
      setCurrentIndex((prev) => (prev + 1) % item.images.length);
    } else if (swipeDistance > 50) {
      setCurrentIndex((prev) => (prev - 1 + item.images.length) % item.images.length);
    }
  };

  return (
    <motion.div 
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.8, delay: index * 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
      className="group flex flex-col gap-[var(--space-4)]"
    >
      <div className="relative aspect-[3/4] overflow-hidden border border-[var(--color-border-subtle)] bg-[#160E06]">
        {/* Loading Indicator */}
        <AnimatePresence>
          {!loadedImages[currentIndex] && (
            <motion.div 
              initial={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-0 flex items-center justify-center"
            >
              <motion.div 
                animate={{ opacity: [0.2, 0.8, 0.2] }}
                transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                className="w-1.5 h-1.5 rounded-full bg-[var(--color-text-secondary)]"
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Dark overlay for film feel */}
        <div className="absolute inset-0 bg-gradient-to-tr from-[#140A04]/40 to-transparent mix-blend-multiply pointer-events-none z-10 transition-opacity duration-500 group-hover:opacity-0" />
        <div className="hero-scanlines z-10 opacity-50 group-hover:opacity-20 transition-opacity duration-500 pointer-events-none" />
        
        <motion.div 
          style={{ y: imageY }} 
          className="w-full h-full relative cursor-grab active:cursor-grabbing"
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={0.2}
          onDragEnd={handleDragEnd}
        >
          {item.images.map((imgSrc: string, i: number) => (
            <img 
              key={i}
              src={imgSrc} 
              alt={`${item.title} ${i + 1}`}
              className={`absolute inset-0 w-full h-full object-cover film-image transition-opacity duration-700 ease-in-out ${i === currentIndex && loadedImages[i] ? 'opacity-100' : 'opacity-0'}`}
              referrerPolicy="no-referrer"
              draggable={false}
              onLoad={() => handleImageLoad(i)}
            />
          ))}
        </motion.div>

        {/* Pagination dots */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 z-20 pointer-events-none">
          {item.images.map((_: any, i: number) => (
            <div 
              key={i} 
              className={`w-1.5 h-1.5 rounded-full transition-colors duration-300 ${i === currentIndex ? 'bg-[var(--color-accent-primary)]' : 'bg-white/30'}`}
            />
          ))}
        </div>
      </div>
      
      <div className="flex flex-col gap-[var(--space-2)]">
        <div className="flex justify-between items-start">
          <h3 className="font-display text-[var(--text-heading-sm)] text-[var(--color-text-primary)] leading-none group-hover:text-[var(--color-accent-primary)] transition-colors duration-300 cursor-pointer">
            {item.title}
          </h3>
          <span className="font-mono text-[var(--text-micro)] tracking-[var(--tracking-widest)] text-[var(--color-accent-primary)] uppercase">
            Lookbook {item.year}
          </span>
        </div>
        <p className="font-body text-[var(--text-body-sm)] text-[var(--color-text-secondary)]">
          {item.description}
        </p>
      </div>
    </motion.div>
  );
}

export function Archives() {
  const { scrollY } = useScroll();
  const [showCTA, setShowCTA] = useState(false);

  useMotionValueEvent(scrollY, "change", (latest) => {
    if (latest > 200) {
      setShowCTA(true);
    } else {
      setShowCTA(false);
    }
  });

  useEffect(() => {
    const el = document.querySelector('.archive-headline');
    if (el) {
      el.classList.add('vhs-glitch');
      setTimeout(() => el.classList.remove('vhs-glitch'), 420);
    }
  }, []);

  return (
    <div className="min-h-screen w-full bg-[var(--color-bg-primary)] transition-colors duration-[var(--duration-mode)] ease-in-out pb-[clamp(4rem,8vw,8rem)]">
      {/* Header Section */}
      <div className="pt-[clamp(6rem,12vw,10rem)] pb-[clamp(4rem,8vw,6rem)] px-[clamp(1.25rem,5vw,4rem)] max-w-[1280px] mx-auto relative">
        <div className="hero-monogram opacity-50 top-0 left-0">
          <span className="mono-ug">UG</span>
        </div>
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-[var(--space-8)] border-b border-[var(--color-border-subtle)] pb-[var(--space-8)]">
          <div>
            <p className="hero-label">HISTORICAL LOOKBOOKS</p>
            <h1 className="hero-headline archive-headline mb-0" data-text="Selected Works.">
              Selected<br /><em>Works.</em>
            </h1>
          </div>
          <p className="font-mono text-[var(--text-micro)] text-[var(--color-text-secondary)] uppercase tracking-[var(--tracking-widest)] max-w-[200px] md:text-right">
            Visual documentation of the 199X movement.
          </p>
        </div>
      </div>

      {/* Lookbook Grid */}
      <div className="max-w-[1280px] mx-auto px-[clamp(1.25rem,5vw,4rem)]">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-[var(--space-4)] sm:gap-x-[var(--space-6)] lg:gap-x-[var(--space-8)] gap-y-[var(--space-10)] sm:gap-y-[var(--space-12)] lg:gap-y-[var(--space-16)]">
          {archiveItems.map((item, index) => (
            <ArchiveItem key={item.id} item={item} index={index} />
          ))}
        </div>
      </div>

      {/* Sticky CTA */}
      <AnimatePresence>
        {showCTA && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-[var(--space-8)] left-1/2 -translate-x-1/2 z-50 pointer-events-auto"
          >
            <button className="bg-[var(--color-bg-primary)]/90 backdrop-blur-md text-[var(--color-text-primary)] border border-[var(--color-border-subtle)] px-[var(--space-6)] py-[var(--space-3)] font-mono text-[var(--text-micro)] uppercase tracking-[var(--tracking-widest)] hover:bg-[var(--color-text-primary)] hover:text-[var(--color-bg-primary)] transition-colors duration-300 shadow-2xl">
              View All Archives
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
