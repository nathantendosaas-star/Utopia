import React, { useEffect, useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Play } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

import { Link } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import { products } from '../data/products';

export function Home() {
  const imagesRef = useRef<HTMLDivElement>(null);
  const { setQuickViewProduct } = useStore();

  useEffect(() => {
    const el = document.querySelector('.hero-headline');
    if (el) {
      el.classList.add('vhs-glitch');
      setTimeout(() => el.classList.remove('vhs-glitch'), 420);
    }
  }, []);

  return (
    <div className="w-full">
      {/* Hero Section - Yin/Yang Split */}
      <section className="hero">
        {/* LEFT — LIGHT ZONE */}
        <div className="hero-light">
          <div className="hero-monogram">
            <span className="mono-ug">UG</span>
            <span className="mono-brand">UTOPIA</span>
          </div>
          <div className="hero-content">
            <p className="hero-label">COLLECTION 2025</p>
            <h1 className="hero-headline" data-text="No Wasted Potential.">
              No Wasted<br /><em>Potential.</em>
            </h1>
            <p className="hero-body">
              A study in analog textures<br />
              and sculptural silhouettes.
            </p>
            <button className="btn-primary">EXPLORE THE DROP</button>
          </div>
        </div>

        {/* RIGHT — DARK ZONE */}
        <div className="hero-dark">
          <img src="/input_file_14.jpg" alt="Utopia UG Campaign" className="hero-img" referrerPolicy="no-referrer" />
          <div className="hero-dark-overlay" />
          <div className="hero-scanlines" />
        </div>
      </section>

      {/* Editorial Banners - High Contrast */}
      <section className="py-[clamp(4rem,8vw,8rem)] px-[clamp(1.25rem,5vw,4rem)] bg-[var(--color-bg-secondary)] transition-colors duration-[var(--duration-mode)] ease-in-out">
        <div className="max-w-[1280px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-[var(--space-6)] items-stretch">
            {/* Left Banner: Minimal Text */}
            <motion.div 
              whileHover={{ y: -3 }}
              className="lg:col-span-4 bg-[var(--color-bg-primary)] p-[var(--space-12)] flex flex-col justify-between min-h-[500px] group border border-[var(--color-border-subtle)] transition-all duration-[var(--duration-base)]"
            >
              <div className="flex flex-col gap-[var(--space-4)]">
                <span className="font-mono text-[var(--text-micro)] uppercase tracking-[var(--tracking-widest)] text-[var(--color-text-secondary)]">01 / Concept</span>
                <h3 className="text-[var(--text-display)] font-display text-[var(--color-text-primary)] leading-[var(--leading-tight)]">The Art of<br/>Omission</h3>
              </div>
              <div className="flex flex-col gap-[var(--space-6)] items-start">
                <p className="text-[var(--text-body-sm)] text-[var(--color-text-secondary)] leading-[var(--leading-relaxed)] max-w-[200px]">
                  Stripping away the noise to reveal the raw essence of form.
                </p>
                <Link to="/shop" className="btn-ghost">Culture Notes</Link>
              </div>
            </motion.div>

            {/* Center Banner: High Fashion Image/Video */}
            <motion.div 
              className="lg:col-span-8 relative min-h-[500px] overflow-hidden group border border-[var(--color-border-subtle)]"
            >
              <video 
                src="/input_file_15.mp4" 
                className="w-full h-full object-cover film-image"
                autoPlay 
                loop 
                muted 
                playsInline
              />
              <div className="absolute inset-0 bg-[var(--color-bg-primary)]/10 group-hover:bg-[var(--color-bg-primary)]/20 transition-all duration-[var(--duration-slow)] flex items-center justify-center pointer-events-none">
                <div className="w-20 h-20 rounded-full border border-[var(--color-border-subtle)] flex items-center justify-center backdrop-blur-sm scale-0 group-hover:scale-100 transition-transform duration-[var(--duration-slow)]">
                  <Play size={24} className="text-[var(--color-text-primary)] ml-1" />
                </div>
              </div>
              <div className="absolute bottom-[var(--space-8)] left-[var(--space-8)] text-[var(--color-text-primary)] z-20 pointer-events-none">
                <span className="font-mono text-[var(--text-micro)] uppercase tracking-[var(--tracking-widest)] opacity-80">Film Still</span>
                <h4 className="text-[var(--text-heading-lg)] font-display mt-[var(--space-2)]">Analog Dreams</h4>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Collection - Refined Grid */}
      <section ref={imagesRef} className="py-[clamp(4rem,8vw,8rem)] px-[clamp(1.25rem,5vw,4rem)] relative z-20 bg-[var(--color-bg-primary)] transition-colors duration-[var(--duration-mode)] ease-in-out">
        <div className="max-w-[1280px] mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-[var(--space-20)] gap-[var(--space-8)]">
            <div className="flex flex-col gap-[var(--space-4)]">
              <span className="font-mono text-[var(--color-accent-primary)] font-bold tracking-[var(--tracking-widest)] uppercase text-[var(--text-micro)]">Curated Selection</span>
              <h2 className="text-[var(--text-display)] font-display uppercase text-[var(--color-text-primary)] tracking-[var(--tracking-tight)] leading-[var(--leading-tight)]">
                Selected<br/>
                <span className="text-[var(--color-text-muted)]">Pieces</span>
              </h2>
            </div>
            <p className="max-w-xs text-[var(--text-body-sm)] font-body text-[var(--color-text-secondary)] leading-[var(--leading-relaxed)] md:text-right">
              "Fashion is not something that exists in dresses only. Fashion is in the sky, in the street, fashion has to do with ideas, the way we live, what is happening."
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-[var(--space-6)]">
            {products.slice(6, 10).map((item, idx) => (
              <motion.div 
                key={item.id} 
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 1, delay: idx * 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
                className="product-card group cursor-pointer"
                onClick={() => setQuickViewProduct(item)}
              >
                <div className="product-card-img-wrapper">
                  {item.badge && (
                    <span className={`product-badge ${
                      item.badge === 'NEW DROP' ? 'badge-new' : 
                      item.badge === 'LIMITED' ? 'badge-limited' : 'badge-movement'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                  <img 
                    src={item.image} 
                    alt={item.name}
                    className="w-full h-full object-cover product-img"
                  />
                  <div className="absolute bottom-0 left-0 w-full h-[40px] bg-[var(--color-bg-primary)]/80 backdrop-blur-[4px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-[var(--duration-base)]">
                    <span className="font-mono text-[11px] uppercase text-[var(--color-text-primary)]">Quick View</span>
                  </div>
                </div>
                <div className="flex flex-col gap-[var(--space-1)]">
                  <h5 className="font-body font-medium text-[15px] text-[var(--color-text-primary)]">{item.name}</h5>
                  <span className="font-mono text-[13px] text-[var(--color-text-secondary)]">${item.price}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
